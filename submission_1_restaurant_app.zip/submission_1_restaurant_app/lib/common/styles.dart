import 'dart:ui';

const Color primaryColor = Color(0xFFFFFFFF);
const Color secondaryColor = Color(0xFFFF6500);

